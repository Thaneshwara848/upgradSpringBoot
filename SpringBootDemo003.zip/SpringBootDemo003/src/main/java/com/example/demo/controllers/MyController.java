package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.services.MyService;

import jakarta.validation.Valid;

@RestController
public class MyController {

    @Autowired
    private MyService service;

    //  Get all employees
    @GetMapping("/allEmployees")
    public List<Employee> allEmployees() {
        return service.getAllEmployees();
    }

    // Get employee by ID
    @GetMapping("/EmployeeById/{id}")
    public Employee allEmployeesById(@PathVariable int id) {
        return service.getEmployeeById(id);
    }

    //  Add new employee 
    @PostMapping("/addEmp")
    public String addEmployee(@Valid @RequestBody Employee employee) {
        return service.addEmployee(employee);
    }

    //  Update existing employee (validation active)
    @PutMapping("/updateEmp/{id}")
    public String updateEmployee(@PathVariable int id, @Valid @RequestBody Employee employee) {
        return service.updateEmployee(id, employee);
    }

    //  Delete employee by ID
    @DeleteMapping("/deleteEmp/{id}")
    public String deleteEmployeeById(@PathVariable int id) {
        return service.deleteEmployeeById(id);
    }

    //  Delete all employees
    @DeleteMapping("/deleteAllEmps")
    public String deleteAllEmployees() {
        return service.deleteAllEmployees();
    }
}
