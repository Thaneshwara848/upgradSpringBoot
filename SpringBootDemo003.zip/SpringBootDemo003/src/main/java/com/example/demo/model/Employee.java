package com.example.demo.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Schema(description = "Employee entity representing an employee record in the company")
public class Employee {

    @Id
    @Positive(message = "ID must be a positive number")
    @Schema(description = "Unique employee ID (positive integer)", example = "101")
    private int id;

    @NotBlank(message = "Name is required")
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Name must contain only letters and spaces")
    @Schema(description = "Full name of the employee (only letters allowed)", example = "Ibrahim Khan")
    private String name;

    @Min(value = 18, message = "Age must be at least 18")
    @Max(value = 60, message = "Age must not exceed 60")
    @Schema(description = "Age of the employee (18-60 range)", example = "25")
    private int age;

    @Min(value = 25000, message = "Salary must be at least 25000")
    @Schema(description = "Monthly salary of the employee (minimum 25000)", example = "50000")
    private int salary;

    @NotBlank(message = "Designation is required")
    @Schema(description = "Job designation of the employee", example = "Software Engineer")
    private String desig;
}
