package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Employee;

public interface MyRepo extends JpaRepository<Employee, Integer> {
    // save
    // find
    // findById
    // delete
    // deleteById
    // deleteAll
    // etc... all these methods are already present in JpaRepository
    // hence we are just extending it!
}
