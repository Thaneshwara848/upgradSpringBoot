package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.EmployeeAlreadyExistsException;
import com.example.demo.exceptions.EmployeeNotFoundException;
import com.example.demo.model.Employee;
import com.example.demo.repo.MyRepo;

@Service
public class MyService {

    @Autowired
    private MyRepo repo;

    // Get all employees
    public List<Employee> getAllEmployees() {
        List<Employee> employees = repo.findAll();
        if (employees.isEmpty()) {
            throw new EmployeeNotFoundException("No employees found in the database");
        }
        return employees;
    }


    // Get employee by ID
    public Employee getEmployeeById(int id) {
        return repo.findById(id)
                     .orElseThrow(() -> new EmployeeNotFoundException("No employees found with this" + " id ") );
    }

    // Add new employee
 // Add new employee
    public String addEmployee(Employee employee) {
        if (repo.existsById(employee.getId())) {
            throw new EmployeeAlreadyExistsException("Employee with ID " + employee.getId() + " already exists");
        }
        repo.save(employee);
        return "Employee Added Successfully!";
    }


    // Update employee
    public String updateEmployee(int id, Employee employee) {
        Optional<Employee> empOptional = repo.findById(id);
        if (empOptional.isPresent()) {
            Employee existingEmp = empOptional.get();
            existingEmp.setName(employee.getName());
            existingEmp.setAge(employee.getAge());
            existingEmp.setSalary(employee.getSalary());
            existingEmp.setDesig(employee.getDesig());
            repo.save(existingEmp);
            return "Employee Updated Successfully!";
        } else {
            return "Employee Not Found!";
        }
    }

    // Delete employee by ID
    public String deleteEmployeeById(int id) {
        if (!repo.existsById(id)) {
            throw new EmployeeNotFoundException("Cannot delete — employee with ID " + id + " not found");
        }
        repo.deleteById(id);
        return "Employee Deleted Successfully!";
    }

    // Delete all employees
    public String deleteAllEmployees() {
        if (repo.count() == 0) {
            throw new EmployeeNotFoundException("No employees to delete — database is already empty");
        }
        repo.deleteAll();
        return "All Employees Deleted Successfully!";
    }
}
