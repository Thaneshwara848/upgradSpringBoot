package com.example.demo.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.model.Employee;
import com.example.demo.services.MyService;

public class AddEmployeeTest {

    @Mock
    private MyService service;

    @InjectMocks
    private MyController controller;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddEmployee_Positive() {

        Employee emp = new Employee(
                1,
                "Ibrahim",
                25,
                50000,
                "Engineer"
        );

        // Mock service response
        when(service.addEmployee(emp))
                .thenReturn("Employee added successfully");

        // Call controller
        String response = controller.addEmployee(emp);

        // THOROUGH CHECKING (like your screenshot)
        assertNotNull(response);
        assertEquals("Employee added successfully", response);

        // VERIFY EMPLOYEE FIELDS sent correctly
        assertEquals(1, emp.getId());
        assertEquals("Ibrahim", emp.getName());
        assertEquals(25, emp.getAge());
        assertEquals(50000, emp.getSalary());
        assertEquals("Engineer", emp.getDesig());

        // VERIFY SERVICE INTERACTION
        verify(service, times(1)).addEmployee(emp);
        verifyNoMoreInteractions(service);
    }

    @Test
    void testAddEmployee_Negative() {

        Employee emp = new Employee(
                1,
                "Ibrahim",
                25,
                50000,
                "Engineer"
        );

        when(service.addEmployee(emp))
                .thenThrow(new RuntimeException("Employee already exists"));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> controller.addEmployee(emp));

        assertEquals("Employee already exists", ex.getMessage());

        // Verify interaction
        verify(service).addEmployee(emp);
    }
}
