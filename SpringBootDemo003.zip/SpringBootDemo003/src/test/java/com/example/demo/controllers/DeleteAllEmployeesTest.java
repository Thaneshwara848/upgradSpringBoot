package com.example.demo.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.services.MyService;

public class DeleteAllEmployeesTest {

    @Mock
    private MyService service;

    @InjectMocks
    private MyController controller;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testDeleteAllEmployees_Success() {

        when(service.deleteAllEmployees())
                .thenReturn("All employees deleted");

        String response = controller.deleteAllEmployees();

        assertNotNull(response);
        assertEquals("All employees deleted", response);

        verify(service).deleteAllEmployees();
        verifyNoMoreInteractions(service);
    }
}
