package com.example.demo.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.services.MyService;

public class DeleteEmployeeByIdTest {

    @Mock
    private MyService service;

    @InjectMocks
    private MyController controller;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testDeleteEmployeeById_Success() {

        when(service.deleteEmployeeById(1))
                .thenReturn("Employee deleted successfully");

        String response = controller.deleteEmployeeById(1);

        assertNotNull(response);
        assertEquals("Employee deleted successfully", response);

        verify(service).deleteEmployeeById(1);
        verifyNoMoreInteractions(service);
    }

    @Test
    void testDeleteEmployeeById_NotFound() {

        when(service.deleteEmployeeById(99))
                .thenThrow(new RuntimeException("Employee not found"));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> controller.deleteEmployeeById(99));

        assertEquals("Employee not found", ex.getMessage());

        verify(service).deleteEmployeeById(99);
        verifyNoMoreInteractions(service);
    }
}
