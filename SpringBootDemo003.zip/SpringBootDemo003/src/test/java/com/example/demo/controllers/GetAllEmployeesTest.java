package com.example.demo.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.model.Employee;
import com.example.demo.services.MyService;

public class GetAllEmployeesTest {

    @Mock
    private MyService service;

    @InjectMocks
    private MyController controller;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllEmployees_Success() {

        List<Employee> mockList = List.of(
                new Employee(1, "Ibrahim", 25, 50000, "Engineer"),
                new Employee(2, "Rahul", 30, 60000, "Manager")
        );

        when(service.getAllEmployees()).thenReturn(mockList);

        List<Employee> result = controller.allEmployees();

        assertNotNull(result);
        assertEquals(2, result.size());

        // First employee
        assertEquals(1, result.get(0).getId());
        assertEquals("Ibrahim", result.get(0).getName());
        assertEquals(25, result.get(0).getAge());
        assertEquals(50000, result.get(0).getSalary());
        assertEquals("Engineer", result.get(0).getDesig());

        // Second employee
        assertEquals(2, result.get(1).getId());
        assertEquals("Rahul", result.get(1).getName());
        assertEquals(30, result.get(1).getAge());
        assertEquals(60000, result.get(1).getSalary());
        assertEquals("Manager", result.get(1).getDesig());

        verify(service).getAllEmployees();
        verifyNoMoreInteractions(service);
    }
}
