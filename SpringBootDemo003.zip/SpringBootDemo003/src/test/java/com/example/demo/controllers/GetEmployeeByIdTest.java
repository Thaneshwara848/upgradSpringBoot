package com.example.demo.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.model.Employee;
import com.example.demo.services.MyService;

public class GetEmployeeByIdTest {

    @Mock
    private MyService service;

    @InjectMocks
    private MyController controller;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetEmployeeById_Success() {

        Employee emp = new Employee(1, "Ibrahim", 25, 50000, "Engineer");

        when(service.getEmployeeById(1)).thenReturn(emp);

        Employee result = controller.allEmployeesById(1);

        assertNotNull(result);
        assertEquals(1, result.getId());
        assertEquals("Ibrahim", result.getName());
        assertEquals(25, result.getAge());
        assertEquals(50000, result.getSalary());
        assertEquals("Engineer", result.getDesig());

        verify(service).getEmployeeById(1);
        verifyNoMoreInteractions(service);
    }

    @Test
    void testGetEmployeeById_NotFound() {

        when(service.getEmployeeById(99))
                .thenThrow(new RuntimeException("Employee not found"));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> controller.allEmployeesById(99));

        assertEquals("Employee not found", ex.getMessage());

        verify(service).getEmployeeById(99);
        verifyNoMoreInteractions(service);
    }
}
