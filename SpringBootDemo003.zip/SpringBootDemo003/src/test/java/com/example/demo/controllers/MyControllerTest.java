package com.example.demo.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.model.Employee;
import com.example.demo.services.MyService;

public class MyControllerTest {

    @Mock
    private MyService service;

    @InjectMocks
    private MyController controller;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetEmployee_Positive() {

        Employee emp = new Employee(
                1,
                "Ibrahim",
                25,
                50000,
                "Engineer"
        );

        when(service.getEmployeeById(1)).thenReturn(emp);

        Employee result = controller.allEmployeesById(1);

        assertEquals("Ibrahim", result.getName());
        assertEquals(25, result.getAge());
        assertEquals(50000, result.getSalary());
        assertEquals("Engineer", result.getDesig());

        verify(service).getEmployeeById(1);
    }

    @Test
    void testGetEmployee_Negative() {

        when(service.getEmployeeById(99))
            .thenThrow(new RuntimeException("Not Found"));

        RuntimeException ex = org.junit.jupiter.api.Assertions.assertThrows(
            RuntimeException.class,
            () -> controller.allEmployeesById(99)
        );

        assertEquals("Not Found", ex.getMessage());

        verify(service).getEmployeeById(99);
    }
}
