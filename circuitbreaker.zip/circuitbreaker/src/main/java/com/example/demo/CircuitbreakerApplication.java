package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CircuitbreakerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CircuitbreakerApplication.class, args);
		System.out.println("Running");
	}
//	https://app.napkin.ai/page/CgoiCHByb2Qtb25lEiwKBFBhZ2UaJDY2YTU4NDM3LTIxODgtNDdjNi1iYzVlLWUzMTA3NjkwNDFjZg

}
