package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
public class ControllerClass {

    @Autowired
    private ServiceClass serviceClass;

    @GetMapping("/cb-test")
    @CircuitBreaker(name = "myCircuitBreaker", fallbackMethod = "fallback")
    public String testCircuitBreaker(@RequestParam boolean fail) {
        return serviceClass.callExternalAPI(fail);
    }

    // Fallback must include Throwable as 2nd parameter
    public String fallback(boolean fail, Throwable t) {
        return "Fallback response — External service unavailable!";
    }
}
