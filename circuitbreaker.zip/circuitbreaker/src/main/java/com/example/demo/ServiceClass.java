package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class ServiceClass {

    public String callExternalAPI(boolean fail) {
        if (fail) {
            throw new RuntimeException("External service failed!");
        }
        return "Success! External service responded.";
    }
}
